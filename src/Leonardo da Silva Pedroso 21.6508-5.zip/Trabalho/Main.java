package Trabalho;

public class Main {
    public static void main(String[] args) {
        ListaCadastro cadastro = new ListaCadastro();
        cadastro.inicia();
    }
}
