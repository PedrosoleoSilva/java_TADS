package Trabalho;

import java.util.ArrayList;

public class Carro {
    String cor;
    String modelo;
    String tipoCombustivel;
    String potencia;
    //Carro[] lista = new Carro[10];
    // public ArrayList<String> listacarros = new ArrayList<>();

}
